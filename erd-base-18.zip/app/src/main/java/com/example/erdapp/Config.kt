package com.example.erdapp

/**
 * ====== تنها فایلی که برای هر نسخه باید عوض بشه ======
 * اسم اپ از strings.xml میاد (چون اندروید اونجا می‌خونه)، ولی آدرس سایت و رنگ تم اینجاست.
 */
object Config {

    // آدرس سایتی که اپ نمایش میده
    const val APP_URL = "https://chatgpt.com"

    // چند میلی‌ثانیه اسپلش (صفحه اول با لوگو) نمایش داده بشه
    const val SPLASH_DURATION_MS = 2500L
}
