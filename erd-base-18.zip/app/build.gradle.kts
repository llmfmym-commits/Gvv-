plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.erdapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.erdapp"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // ====== جای SDK تبلیغاتی تپسل ======
    // وقتی از پنل Tapsell کد رسمی SDK رو گرفتی، خط implementation مربوطه رو اینجا اضافه کن.
    // این پروژه بدون تبلیغ هم کامل کامپایل و اجرا میشه.
}
